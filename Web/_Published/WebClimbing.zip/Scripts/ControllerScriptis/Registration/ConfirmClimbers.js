﻿function btnSubmit_Click() {
    $("#goback").val("false");
    $(".hide-when-edit").hide();
}

function btnBack_Click() {
    $("#goback").val("true");
    $(".hide-when-edit").hide();
}